document.addEventListener('DOMContentLoaded', () => {
    const group11 = document.querySelector('.section-fourth .group-11');
    if (!group11) {
      console.error('group-11 element not found!');
      return;
    }

    const images = group11.querySelectorAll('img[class^="unsplash"]');
    if (images.length === 0) {
      console.error('No unsplash images found inside group-11!');
      return;
    }

    const centralIcon = group11.querySelector('.element-clinic');
    if (!centralIcon) {
      console.error('Central icon (element-clinic) not found!');
    }

    const ellipse1 = group11.querySelector('.ellipse');
    const ellipse2 = group11.querySelector('.ellipse-2');
    if (!ellipse1 || !ellipse2) {
      console.error('Background ellipses not found!');
    }

    const radii = [250, 180, 250, 220];
    const speed = 0.02;

    const pulseSpeed = 0.005;
    const pulseAmplitude = 0.1;

    let angle = 0;
    let pulseAngle = 0;

    const imageData = Array.from(images).map((img, index) => {
      const rect = img.getBoundingClientRect();
      return {
        element: img,
        centerX: 500 / 2,
        centerY: 500 / 2,
        initialX: rect.left + rect.width / 2 - group11.getBoundingClientRect().left,
        initialY: rect.top + rect.height / 2 - group11.getBoundingClientRect().top,
        radius: radii[index % radii.length],
        angleOffset: (2 * Math.PI * index) / images.length,
      };
    });

    function animate() {
      angle += speed;
      pulseAngle += pulseSpeed;

      imageData.forEach((data) => {
        const x = data.centerX + data.radius * Math.cos(angle + data.angleOffset);
        const y = data.centerY + data.radius * Math.sin(angle + data.angleOffset);

        data.element.style.transform = `translate(${x - data.initialX}px, ${y - data.initialY}px)`;
      });

      if (ellipse1 && ellipse2) {
        const scale1 = 1 + pulseAmplitude * Math.sin(pulseAngle);
        const scale2 = 1 + pulseAmplitude * Math.cos(pulseAngle);

        ellipse1.style.transform = `scale(${scale1})`;
        ellipse2.style.transform = `scale(${scale2})`;
      }

      requestAnimationFrame(animate);
    }

    animate();
  });